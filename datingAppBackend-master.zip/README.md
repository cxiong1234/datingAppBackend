Dating App Back end

##1.Set up database in docker:
run the following command in terminal: <br>
`docker run --name some-postgres -p 5432:5432 -e POSTGRES_PASSWORD=mysecretpassword -d postgres` <br>
Where your container name:some-postgres <br>
User name: postgres <br>
password: mysecretpassword <br>
database name: postgres <br>

##2.Connect the database on IntelliJ:
Please follow the Youtube Video step by step: <br>
https://www.youtube.com/watch?v=y59APSl0mzk&ab_channel=ManikantaMaddipati

